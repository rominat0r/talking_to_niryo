import serial 
from time import sleep


class Robot:
    def __init__(self, port):
        self.dev = serial.Serial(port, baudrate=9600)
        sleep(1)

    def query(self, message):
        self.dev.write(message.encode())
        
    def move(self,base,shoulder,elbow,elbow_servo,wrist_servo):
        sleep(1)
        case = 2
        self.query(str(case) + ',' + str(base) + ',' + str(shoulder)+','+ str(elbow) + '\n')
    def distance(self):
        line = self.dev.readline().decode('ascii').strip()
        return line
    def grip_catch(self):
        sleep(1)
        case = 0
        self.query(str(case) + ',' + str(0)+','+ str(0) + ',' + str(0) + '\n')
    def grip_release(self):
        sleep(1)
        case = 1
        self.query(str(case) + ',' + str(0)+','+ str(0) + ',' + str(0) + '\n')

