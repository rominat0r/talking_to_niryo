import serial 
from time import sleep


class Robot:
    def __init__(self, port):
        self.dev = serial.Serial(port, baudrate=9600)
        sleep(1)

    def query(self, message):
        sleep(1)
        self.dev.write(message.encode())
        # line = self.dev.readline().decode('ascii').strip()
        # return line
    def Move(self,base,shoulder,elbow,elbow_servo,wrist_servo):
        sleep(1)
        self.query(str(shoulder)+','+str(elbow)+ '\n')